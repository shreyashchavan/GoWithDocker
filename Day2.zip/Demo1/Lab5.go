package main
import (
	"fmt"
	"os"
)
/*
import "fmt"
import "os"
*/
func main(){
	fmt.Println(os.Args)
	fmt.Println("Length = " , len(os.Args))
	fmt.Println("Length of second argument = " , len(os.Args[1]))

}