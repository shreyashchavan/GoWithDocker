package main
import "fmt"

type Display interface {
	print()
}
 
type Employee struct {
	Empno  int
	Ename  string
	Salary float64
}
 
func (e Employee) print() {
	fmt.Println(e)
}
 
func main() {
	var display Display
	emp := Employee{1, "test", 12000}
	fmt.Println("display and employee created", display, emp)
	display = emp
	display.print()
	emp.print()
}
