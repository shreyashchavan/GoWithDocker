package main
import "fmt"
type point struct{
	x int
	y int
}
func (p *point) shift( dx int, dy int)  {
	 p.x += dx
	 p.y += dy
	}
func (p point) printPoint() {
	fmt.Printf("Coordinates: x = %d, y = %d", p.x, p.y)
}
func main() {
	v1 := point{x:4, y:6}
	fmt.Println(v1)
	v1.shift( 1,1)
	fmt.Println(v1)
	v1.printPoint()
}
