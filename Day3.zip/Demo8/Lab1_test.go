package main

import "testing"

func TestSqr(t *testing.T) {
	got := sqr(10)
	if got != 100 {
		t.Errorf("Sqr(10) = %d; want 100", got)
	}
}

func TestAdd(*testing.T) {

}
func TestDiv1(t *testing.T) {
	got := div(10, 5)
	if got != 2 {
		t.Errorf("div(10,5) = %d; want 2", got)
	}
}
func TestDiv2(t *testing.T) {
	defer func() {
		if r := recover(); r == nil {
			t.Errorf("Div of 10,0 should raise panic")
		}
	}()
	div(10, 0)
}

func BenchmarkSqr(b *testing.B) {
	for i := 0; i < b.N; i++ {
		sqr(i)
	}
}
