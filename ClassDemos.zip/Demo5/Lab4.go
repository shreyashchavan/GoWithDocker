package main
 
import "fmt"
import "strconv" 
func main() {
	ch := make(chan string)
	go read(ch)
	go write("Blr", ch)
 	//fmt.Println("waiting for some data from channel")
	for {}
}
func read(ch chan string) {
	fmt.Println("Reading data from channel")
	for msg := range ch	{
	fmt.Println("Data from channel ", msg)
	}
	fmt.Println("Reading Done !!")
}
 
func write(str string, ch chan string) {
	for i:=1; i<= 3;i++{
		fmt.Println("Writing data to channel" , i )
		ch <- str + strconv.Itoa(i) + " done !! "
	}
}