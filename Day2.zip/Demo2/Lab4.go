package main
import "fmt"
func incr(i *int){
	*i = *i + 1
	fmt.Println("in incr "  , i )
}
func main() {
	i := 42
	p := &i
	fmt.Println("i = " , i , " and P = ", p)
	incr(p)
	fmt.Println("i = " , i , " and P = ", p)
	incr(p)
	
}
