package main
import "fmt"

type Connection interface{
	open()
	close()
}

type OracleConnection struct{
}

func (c OracleConnection) open(){
	fmt.Println("Open implemented ")
}
func (c OracleConnection) close(){
	fmt.Println("Close implemented ")
}

func main() {
	var con Connection
	oracon := OracleConnection{}
	fmt.Println("Con and OracCon created", con , oracon )
	con = oracon
	con.open()
	con.close()
	
}
