package main
import (
	"fmt"
	"time"
	"sync"
)
var total = 0
func main(){
	var mux sync.Mutex
	go deposit(&mux)
	go widraw(&mux)
	time.Sleep(3500 * time.Millisecond)
	fmt.Println("Final Total = " , total)
}
func deposit(mux *sync.Mutex){
	for i:=0; i< 100;i++{
		mux.Lock()
		bal:= total
		bal++
		time.Sleep(10 * time.Millisecond)
		total = bal
		mux.Unlock()
	}
	fmt.Println("Done Deposit ", total)
}
func widraw(mux *sync.Mutex){
	for i:=0; i< 100;i++{
		mux.Lock()
		bal:= total
		bal--
		time.Sleep(10 * time.Millisecond)
		total = bal
		mux.Unlock()
	}
	fmt.Println("Done Widraw ", total)
}