package main
import "fmt"
func hello(){
	fmt.Println("hello func invoked ...")
}
func sqr (no1 int) int {
	return no1*no1
}

func calc (no1 int, no2 int) (int, int) {
	return no1+no2, no1*no2
}

func add (no1 int, no2 int) int {
	return no1+no2
}
func mult (no1 int, no2 int) int {
	return no1*no2
}
func main(){
	var no1 = 100
	no2 := 200
	fmt.Println("Sum = " , no1+no2)
	hello()
	ans := sqr(20)
	fmt.Println("SQR of 20 is ", ans)
	fmt.Println("Sum of 10, 1000 is " , add(10, 1000))
	fmt.Println("Multiplication of 10, 1000 is " , mult(10, 1000))
	s, m := calc(10,20)
	fmt.Println(" Sum = " , s , " Multiplication = " , m)

}