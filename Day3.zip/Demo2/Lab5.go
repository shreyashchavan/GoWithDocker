package main
import "fmt"
type point struct{
	x int
	y int
}
func shift(p *point, dx int, dy int)  {
	 p.x += dx
	 p.y += dy
	}
func printPoint(p point) {
	fmt.Printf("Coordinates: x = %d, y = %d", p.x, p.y)
}
func main() {
	v1 := point{}
	fmt.Println(v1)
	v1 = point{1,5}
	fmt.Println(v1)
	v1 = point{x:1}
	fmt.Println(v1)
	v1 = point{y:5}
	fmt.Println(v1)
	v1 = point{x:4, y:6}
	fmt.Println(v1)
	shift(&v1, 1,1)
	fmt.Println(v1)
	printPoint(v1)
}
