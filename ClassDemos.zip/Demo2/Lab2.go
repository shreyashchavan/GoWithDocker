package main
import "fmt"
func main() {
	defer myrecovery()
	process()
	fmt.Println("Last line of main method")
}
func myrecovery(){
	r:= recover()
	fmt.Println("Recover = " , r)
}

func process(){
	for i:=0;i<5;i++{
		fmt.Println("Process - ", i)
		if i == 3 {
			panic("Some Problem...")
		}
	}
}