package main
import (
	"fmt"
	"sort"
)
func fibonacci(num int){
    num1, num2, i , num3  := 0, 1,0,0
    fmt.Println(num1);
    fmt.Println(num2);
 
    for i = 2; i < num; i++{
        num3 = num1 + num2;
        num1 = num2;
        num2 = num3;
        fmt.Println(num3);
    }
}
func Fibonacci(x int) int {
	if x == 0 {
		return 0
	} else if x <= 2 {
		return 1
	} else {
		return Fibonacci(x-2) + Fibonacci(x-1)
	}
}
 
func main() {
	totalNum := 0
	fmt.Println("Enter total number of terms: ")
	fmt.Scanf("%d", &totalNum)
	for i := 0; i < totalNum; i++ {
		fmt.Printf("%d ", Fibonacci(i))
	}
	fmt.Println("\n\n Other Type")
	
	fibonacci(totalNum);
	fmt.Println("----------Sorted Strings ------------")
	s := []string{"Go", "Bravo", "Gopher", "Alpha", "Grin", "Delta"}
	sort.Strings(s)
	fmt.Println(s)
}