package main

import "fmt"

func sqr(no1 int) int {
	// http get
	return no1 * no1
}
func add(no1 int, no2 int) int {
	return no1 + no2
}
func div(no1 int, no2 int) int {
	return no1 / no2
}
func main() {
	ans := sqr(20)
	fmt.Println("SQR of 20 is ", ans)
	fmt.Println("Sum of 10, 1000 is ", add(10, 1000))
	fmt.Println("Division of 100, 10 is ", div(100, 10))

}
