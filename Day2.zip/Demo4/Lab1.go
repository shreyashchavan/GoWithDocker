package main

import (
	"fmt"
	"net/http"
	"io"
)

func main() {
	resp, err := http.Get("https://reqres.in/api/users/1")
	fmt.Println("Response = ", resp, " Error = ", err)
	if err != nil {
		fmt.Println("Error - ", err)
		return
	}
	defer resp.Body.Close()
	fmt.Println("Status = " , resp.Status)
	fmt.Println("Body = " , resp.Body)
	
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		fmt.Println("Readall Error - ", err)
		return
	}
	fmt.Println("Body ", string(body))
}
