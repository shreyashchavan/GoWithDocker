package main
import (
	"fmt"
	"github.com/magiconair/properties"
	"os"
	"log"
)

func main() {
	f, err := os.OpenFile("demo.log", os.O_RDWR|os.O_CREATE|os.O_APPEND, 0666)
    if err != nil {
        fmt.Println("error opening file: %v", err)
    } else{
    	defer f.Close()
	}
    log.SetOutput(f)
    log.Println("This is a test log entry")

	p := properties.MustLoadFile("my.properties", properties.UTF8)
	host := p.MustGetString("host")
	port := p.GetInt("port", 8080)
	fmt.Println(host , " ,  ", port)
}