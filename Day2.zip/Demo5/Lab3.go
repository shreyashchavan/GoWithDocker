package main

import "fmt"

func main(){
	ch := make(chan string)
	go helper("Pnq", ch)
	go helper("Blr", ch)
	go helper("Hyd", ch)
	fmt.Println("waiting for some data from channel")
	v:= <-ch
	fmt.Println("got data from channel ", v)
	v= <-ch
	fmt.Println("got data from channel ", v)
	v= <-ch
	fmt.Println("got data from channel ", v)

}
func helper(str string, ch chan string){
	for i:=1; i< 60;i++{
		fmt.Print(str , i , " ")
	}
	ch <- str + " done !! "
}