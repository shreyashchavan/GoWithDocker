package main
import "fmt"
func main() {
	a := make([]int, 0) 
	fmt.Println(a , " len = " , len(a), ", cap = " , cap(a)) 
	a = append(a, 6) 
	
	fmt.Println(a , " len = " , len(a), ", cap = " , cap(a)) 
	a = append(a, 6) 
	
	fmt.Println(a , " len = " , len(a), ", cap = " , cap(a)) 
	
	a = append(a, 6) 
	a = append(a, 7) 
	a = append(a, 8)
	a = append(a, 9)
	a = append(a, 1)
	fmt.Println(a , " len = " , len(a), ", cap = " , cap(a)) 
	a = append(a, 1) 
	fmt.Println(a , " len = " , len(a), ", cap = " , cap(a)) 
	for i, v := range a {
		fmt.Printf("2**%d = %d\n", 1, v)
	}
}


