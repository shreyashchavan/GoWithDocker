package main
    
import (
	"io"
	"net/http"
	"dbcon"
	"fmt"
	"strconv"
	"encoding/json"
)
var empmgr=dbcon.EmpMgr{}
func main(){
	
	for i := 0; i < 5; i++ {
		emp := dbcon.Emp {i, "Ename"+ strconv.Itoa(i), int64(i * 100)}
		empmgr.Add(emp)
	}
	http.HandleFunc("/emps", emps)
	
	http.ListenAndServe(":8080", nil)
}

func emps (w http.ResponseWriter, r *http.Request) {
	if r.Method=="GET" {
		emparr := empmgr.Get()
		fmt.Println(emparr)
		barr, _ :=json.Marshal(emparr)
		w.Write(barr)
		
	} else if r.Method=="POST"{
		body := r.Body
		barr := [300]byte{}
		n, e:=body.Read(barr) 
		fmt.Println("in post" , n, e)
		emp := dbcon.Emp{}
		e = json.Unmarshal(barr, &emp)
		io.WriteString(w, "POST method invoked  with " )
		fmt.Println(emp,  "" ,e)
	}
}
