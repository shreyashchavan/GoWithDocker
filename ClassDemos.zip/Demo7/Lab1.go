package main

import (
	"fmt"
	"net/http"
	"io"
)
func main(){
	http.HandleFunc("/bar", bar)
	http.HandleFunc("/", index)
	fmt.Println("Starting Server on 8080...")
	http.ListenAndServe(":8080", nil)
	
}

func index (w http.ResponseWriter, r *http.Request) {
	io.WriteString(w,"<h1>Hello World of Index Page!!</h1>" )
	io.WriteString(w, "Method = "+ r.Method)

}

func bar(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintln(w, "Hello,", r.URL.Path)
}

