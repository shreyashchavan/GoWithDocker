package main
import "fmt"
func main() {
	primes := [6]int{2, 3, 5, 7, 11, 13}
	fmt.Println("Length = " , len(primes), "Capacity = " , cap(primes))

	sl1 := primes[0:2]
	fmt.Println(sl1)
	fmt.Println("Length = " , len(sl1), "Capacity = " , cap(sl1))
	sl1[0] = 100
	fmt.Println(sl1)
	fmt.Println(primes)

	sl2:= primes[1:3]
	fmt.Println(sl2)
	fmt.Println("Length = " , len(sl2), "Capacity = " , cap(sl2))
	
}
