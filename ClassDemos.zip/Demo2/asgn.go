package main
 
import "fmt"
 
type Employee struct {
    Empno   int
    Empname string
    Salary  int64
}
type EmployeeList struct {

} 
type EmpArr [2]Employee

func (emp *Employee) incrementSalary(percent int) {
    emp.Salary += ((emp.Salary * int64(percent)) / 100)
}
 
 
func (emp Employee) printEmployeeSalaries() {
    fmt.Printf("\n Name : %s, Salary : %d", emp.Empname, emp.Salary)
}
 
func (empl *EmpArr) incrementSalaries(percent int) {
    for _, val:= range empl{
        val.Salary += (val.Salary * int64(percent)/100)
		fmt.Println(val.Salary)
    }
}
 
func main() {
    var emplist EmpArr
    var eno int
    var name string
    var salary int64
    for i := 0; i < len(emplist); i++ {
        fmt.Println("Enter Employee No., Name and Salary seperated by space")
        fmt.Scan(&eno, &name, &salary)
        emplist[i].Empno = eno
        emplist[i].Empname = name
        emplist[i].Salary = salary
    }
 
    fmt.Println(emplist)
 
    for i := 0; i < len(emplist); i++ {
        emplist[i].incrementSalary(10)
    }
 
    for i := 0; i < len(emplist); i++ {
        emplist[i].printEmployeeSalaries()
    }
 
    emplist.incrementSalaries(15)
 
	for i := 0; i < len(emplist); i++ {
        emplist[i].printEmployeeSalaries()
    }

}