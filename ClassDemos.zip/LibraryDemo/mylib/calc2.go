package calc

func Add(no1 int, no2 int) int {
	return no1 + no2
}
func Div(no1 int, no2 int) int {
	return no1 / no2
}