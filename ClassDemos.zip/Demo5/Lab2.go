package main

import (
	"fmt"
	"time"
)

var globalvar bool = true
var finalcity string = ""

func main() {
	go helper("-")
	go helper("*")
	go helper("x")
	fmt.Println("main closing")
	time.Sleep(500 * time.Millisecond)
	fmt.Println("Final City is ", finalcity)
	/// stopping main from closing
	/*
		1. Sleep
		2. Ask for some input
		3. for {}
	*/
}
func helper(str string) {
	for i := 1; i < 1000 && globalvar == true; i++ {
		fmt.Print(str, i, " ")
	}
	if globalvar == true {
		globalvar = false
		finalcity = str
	}
}
