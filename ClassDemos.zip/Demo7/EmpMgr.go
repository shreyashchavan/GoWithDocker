// CRUD operation on Emp
package main 
 
import (
	"fmt"
	"strconv"
)
 
type Emp struct {
    Empno   int
    Empname string
    Salary  int64
}

func (emp *Emp) incrementSalary(percent int) {
    emp.Salary += ((emp.Salary * int64(percent)) / 100)
}
func (emp Emp) print() {
    fmt.Printf("\nEmpno: %d \tName : %s, \tSalary : %d",emp.Empno, emp.Empname, emp.Salary)
}
type EmpMgr struct {
	emparr []Emp 
} 
func (empmgr *EmpMgr) add(emp Emp) {
    fmt.Println("empmgr add with " , emp)
	empmgr.emparr = append(empmgr.emparr, emp)
}
func (empmgr EmpMgr) print() {
	// modify range
	for i := 0; i < len(empmgr.emparr); i++ {
		empmgr.emparr[i].print()	
	}
 
}

func main() {
	
	// create instance of empmgr
	empmgr := EmpMgr{}
	for i := 0; i < 5; i++ {
		emp := Emp {i, "Ename"+ strconv.Itoa(i), int64(i * 100)}
		empmgr.add(emp)
		 
	}
	// print fo empmgr
		empmgr.print()
}