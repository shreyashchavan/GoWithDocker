package main
import "fmt"

func main(){
	//var name = "Vaishali"
	//name := "Vaishali"
	//sal := 100
	name , sal :=  "Vaishali", 100
	fmt.Println("My Name is ", name , " and Salary is " , sal)
	fmt.Printf("My Name is %s and Salary is %d ", name, sal)

	//name := "Inder"
	//sal := 200
	name , salary :=  "Inder", 200
	fmt.Println("\nMy Name is ", name , " and Salary is " , salary)
	fmt.Printf("My Name is %s and Salary is %d ", name, salary)


}