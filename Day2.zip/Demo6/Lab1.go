package main

import (
	"database/sql"
	_ "github.com/lib/pq"

	"fmt"
)

func main(){
	//connStr := "user=pqgotest dbname=pqgotest sslmode=verify-full"
	connStr := "postgres://postgres:postgres@localhost/postgres?sslmode=disable"
	var err error
	db, err := sql.Open("postgres", connStr)
	if err == nil {
		fmt.Println("before insert")
		rowcnt, err := db.Exec(`INSERT INTO emp11(empno, ename, salary)
		VALUES(2, 'Two', 2222) `)
		fmt.Println("after insert " , err)
		if err == nil {
			cnt, err :=rowcnt.RowsAffected()
			if err == nil {
				fmt.Println("RowCount =" , cnt )
			}
		}
	}
	fmt.Println("Error = " , err)
}