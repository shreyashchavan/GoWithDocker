package main
import (
	"fmt"
	"abc.com/mylibdemo"
)

func main(){
	s := calc.Sqr(10)
	fmt.Println("Sqr of 10 is ", s)
	s = calc.Add(10,1000)
	fmt.Println("Add = ", s)
	s = calc.Div(10,2)
	fmt.Println("Div is ", s)
}