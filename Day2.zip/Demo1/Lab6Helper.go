package main

func swap(name1, name2 string) (string, string) {
	return name2, name1
}
func calc (no1 int, no2 int) (sum, sub, mult, div int) {
	sum, sub, mult, div =  no1+no2, no1-no2, no1*no2, no1/no2
	return
}