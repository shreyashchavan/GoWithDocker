package main
import "fmt"
func main() {
	i := 0
	defer fmt.Println("Hello " , i)   // evaluation happens here
	fmt.Println("World ")
	help1()
	help2()
}

func help1(){
	defer fmt.Println("defer of help1 ")
	fmt.Println("help1 - 1")
	fmt.Println("help1 - 2")
}
func help2(){
	for i:=0;i<5;i++{
		defer fmt.Println("help2 - ", i)
	}
}
