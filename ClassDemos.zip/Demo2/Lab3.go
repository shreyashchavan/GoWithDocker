package main
import "fmt"
// pass function as input/output argument
func hello(fn func() string ){
	fmt.Println("hello invoked with " , fn())
}
func ab() string{
	return "abc"
}
func sum() func(int) int {
	counter:=0
	return func(x int) int {
		counter += x
		return counter
	}
}
func main() {
	hello(ab)
	fn := sum()
	fmt.Println(fn)
	fmt.Println("fn of 10 returned ", fn(10))
	fmt.Println("fn of 10 returned ", fn(10))
	fmt.Println("fn of 10 returned ", fn(10))
	fmt.Println("fn of 10 returned ", fn(10))
}
