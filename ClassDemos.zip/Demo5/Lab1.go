package main

import "fmt"

func main(){
	go helper("hello")
	go helper("world")
	fmt.Println("main closing")
	for{}
	/// stopping main from closing
	/*
		1. Sleep
		2. Ask for some input
		3. for {}
	*/
}
func helper(str string){
	for i:=1; i< 100;i++{
		fmt.Print(str , i , " ")
	}
}