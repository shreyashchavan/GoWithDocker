package calc


func Sqr(no1 int) int {
	return no1 * no1
}
