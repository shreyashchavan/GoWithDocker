package main
import (
	"fmt"
	"encoding/json"
) 
 
type Emp struct {
	Empno  int    `json:"empnumber"`
	Ename  string `json:"empname"`
	Salary int    `json:"empsalary"`
}
func main(){
	//func Marshal(v any) ([]byte, error)
	emp := Emp{1, "One",111}
	bytes, err := json.Marshal(emp)
	fmt.Println(string(bytes) , " , " , err)
	emp1 := Emp{}
	err = json.Unmarshal(bytes, &emp1) 
	fmt.Println(emp1)

	fmt.Println(err)
	

}