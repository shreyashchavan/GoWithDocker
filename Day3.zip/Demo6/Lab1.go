package main

import (
	"database/sql"
	_ "github.com/lib/pq"

	"fmt"
)

func main(){
	//connStr := "user=pqgotest dbname=pqgotest sslmode=verify-full"
	connStr := "postgres://postgres:postgres@localhost/postgres?sslmode=disable"
	var db *sql.DB
	var err error
	
	if db, err = sql.Open("postgres", connStr); err == nil {
		var rowcnt sql.Result
		str :=`INSERT INTO emp(empno, ename, salary) VALUES(1, 'Two', 2222) `
		if rowcnt, err = db.Exec(str); err == nil {
			var cnt int64
			if cnt, err =rowcnt.RowsAffected(); err == nil {
				fmt.Println("RowCount =" , cnt )
			}
		}
	}
	fmt.Println("Error = " , err)
}